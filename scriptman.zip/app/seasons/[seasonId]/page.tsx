"use client"

import type React from "react"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import {
  ArrowLeft,
  Calendar,
  Clock,
  Copy,
  Download,
  Edit,
  FileText,
  Grid,
  List,
  MapPin,
  Plus,
  Search,
  SlidersHorizontal,
  Trash,
  LayoutTemplate,
} from "lucide-react"
import { GameCard } from "@/components/game-card"
import { ActivityFeed } from "@/components/activity-feed"
import { AddGameDialog } from "@/components/add-game-dialog"
import { BatchAddGamesDialog } from "@/components/batch-add-games-dialog"
import { getSeason, getGames, updateSeason, deleteGame, getActivities } from "@/lib/db"
import type { Season, Game, Activity } from "@/lib/types"
import { formatDate } from "@/lib/utils"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { ChevronDown } from "lucide-react"

interface SeasonPageProps {
  params: {
    seasonId: string
  }
}

export default function SeasonPage({ params }: SeasonPageProps) {
  const { seasonId } = params
  const router = useRouter()
  const [viewMode, setViewMode] = useState<"list" | "grid">("grid")
  const [searchTerm, setSearchTerm] = useState("")
  const [showEditSeasonDialog, setShowEditSeasonDialog] = useState(false)
  const [showAddGameDialog, setShowAddGameDialog] = useState(false)
  const [showBatchAddGamesDialog, setShowBatchAddGamesDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState<string | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [season, setSeason] = useState<Season | null>(null)
  const [games, setGames] = useState<Game[]>([])
  const [activities, setActivities] = useState<Activity[]>([])

  // Fetch season and games data
  useEffect(() => {
    const fetchData = async () => {
      try {
        setIsLoading(true)
        console.log(`Fetching season with ID: ${seasonId}`)
        const seasonData = await getSeason(seasonId)

        if (!seasonData) {
          console.error(`Season with ID ${seasonId} not found`)
          // You could redirect to the dashboard here if needed
          // router.push('/');
          return
        }

        console.log("Season data retrieved:", seasonData)
        const gamesData = await getGames(seasonId)
        const activitiesData = await getActivities(10)

        // Add this code to calculate game counts
        const completedGames = gamesData.filter((game) => game.status === "completed").length
        const seasonWithGameCounts = {
          ...seasonData,
          gameCount: gamesData.length,
          completedGames,
        }

        setSeason(seasonWithGameCounts)
        setGames(gamesData)
        setActivities(activitiesData)
      } catch (error) {
        console.error("Error fetching data:", error)
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [seasonId])

  // Filter games based on search term
  const filteredGames = games.filter(
    (game) =>
      game.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      game.location.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (game.theme && game.theme.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (game.titleSponsor && game.titleSponsor.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  // Handle duplicate game
  const handleDuplicateGame = (gameId: string) => {
    const gameToDuplicate = games.find((game) => game.id === gameId)
    if (!gameToDuplicate) return

    // In a real implementation, this would call an API to duplicate the game
    console.log(`Duplicating game: ${gameId}`)
    // After duplication, you would refresh the games list
  }

  // Handle delete game
  const handleDeleteGame = async (gameId: string) => {
    try {
      await deleteGame(gameId)
      setGames(games.filter((game) => game.id !== gameId))
      setShowDeleteDialog(null)
    } catch (error) {
      console.error("Error deleting game:", error)
    }
  }

  // Handle edit season
  const handleEditSeason = async (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault()
    const formData = new FormData(event.currentTarget)

    try {
      if (!season) return

      const updatedSeason = await updateSeason(seasonId, {
        title: formData.get("title") as string,
        sport: formData.get("sport") as string,
        year: Number.parseInt(formData.get("year") as string),
        description: formData.get("description") as string,
        status: formData.get("status") as string,
      })

      setSeason(updatedSeason)
      setShowEditSeasonDialog(false)
    } catch (error) {
      console.error("Error updating season:", error)
    }
  }

  // Handle game added
  const handleGameAdded = (newGame: Game) => {
    setGames([...games, newGame])
  }

  // Handle multiple games added
  const handleGamesAdded = (newGames: Game[]) => {
    setGames([...games, ...newGames])
  }

  // Handle export season
  const handleExportSeason = () => {
    // In a real implementation, this would generate and download a PDF or CSV
    console.log("Exporting season")
  }
  if (isLoading) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex items-center justify-center h-64">
          <p>Loading season data...</p>
        </div>
      </div>
    )
  }

  if (!season) {
    return (
      <div className="container mx-auto p-6">
        <div className="flex flex-col items-center justify-center h-64 gap-4">
          <p className="text-xl">Season not found</p>
          <p className="text-muted-foreground">The season with ID {seasonId} could not be found.</p>
          <Link href="/">
            <Button>Return to Dashboard</Button>
          </Link>
        </div>
      </div>
    )
  }

  return (
    <main className="container mx-auto p-6">
      {/* Back button and header */}
      <div className="mb-4">
        <Link href="/">
          <Button variant="ghost" className="flex items-center gap-2 pl-0">
            <ArrowLeft className="h-4 w-4" />
            Back to Dashboard
          </Button>
        </Link>
      </div>

      {/* Season header */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-3xl font-bold">{season.title}</h1>
          <p className="text-muted-foreground">
            Sport: {season.sport} • Year: {season.year} • Status:{" "}
            {season.status ? season.status.charAt(0).toUpperCase() + season.status.slice(1) : "In Progress"}
          </p>
          {season.description && <p className="text-muted-foreground mt-2 max-w-2xl">{season.description}</p>}
        </div>
        <div className="flex items-center gap-2">
          <Dialog open={showEditSeasonDialog} onOpenChange={setShowEditSeasonDialog}>
            <Button variant="outline" className="flex items-center gap-2" onClick={() => setShowEditSeasonDialog(true)}>
              <Edit className="h-4 w-4" />
              Edit Season
            </Button>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>Edit Season</DialogTitle>
              </DialogHeader>
              <form onSubmit={handleEditSeason} className="space-y-4 py-4">
                <div className="grid gap-2">
                  <Label htmlFor="title">Season Title</Label>
                  <Input id="title" name="title" defaultValue={season.title} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="sport">Sport</Label>
                  <Select defaultValue={season.sport} name="sport">
                    <SelectTrigger>
                      <SelectValue placeholder="Select a sport" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="Football">Football</SelectItem>
                      <SelectItem value="Basketball">Basketball</SelectItem>
                      <SelectItem value="Baseball">Baseball</SelectItem>
                      <SelectItem value="Soccer">Soccer</SelectItem>
                      <SelectItem value="Hockey">Hockey</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="year">Year</Label>
                  <Input id="year" name="year" type="number" defaultValue={season.year} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="description">Description (Optional)</Label>
                  <Textarea id="description" name="description" defaultValue={season.description || ""} />
                </div>
                <div className="grid gap-2">
                  <Label htmlFor="status">Status</Label>
                  <Select defaultValue={season.status || "draft"} name="status">
                    <SelectTrigger>
                      <SelectValue placeholder="Select a status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="draft">Draft</SelectItem>
                      <SelectItem value="in-progress">In Progress</SelectItem>
                      <SelectItem value="completed">Completed</SelectItem>
                      <SelectItem value="archived">Archived</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <DialogFooter>
                  <Button type="submit">Save Changes</Button>
                </DialogFooter>
              </form>
            </DialogContent>
          </Dialog>
          <Button variant="outline" className="flex items-center gap-2" onClick={handleExportSeason}>
            <Download className="h-4 w-4" />
            Export Season
          </Button>
        </div>
      </div>

      {/* Games section with filters and view toggle */}
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-4 gap-4">
          <h2 className="text-xl font-semibold">Games</h2>
          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="relative flex-1 sm:flex-none">
              <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search games..."
                className="pl-8 w-full sm:w-[250px]"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
            <Button variant="outline" size="icon" title="Filter">
              <SlidersHorizontal className="h-4 w-4" />
            </Button>
            <Tabs value={viewMode} onValueChange={(value) => setViewMode(value as "list" | "grid")}>
              <TabsList>
                <TabsTrigger value="grid" title="Grid View">
                  <Grid className="h-4 w-4" />
                </TabsTrigger>
                <TabsTrigger value="list" title="List View">
                  <List className="h-4 w-4" />
                </TabsTrigger>
              </TabsList>
            </Tabs>
          </div>
        </div>

        {/* Games list/grid */}
        {viewMode === "grid" ? (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGames.map((game) => (
              <GameCard
                key={game.id}
                game={game}
                seasonId={seasonId}
                onDuplicate={() => handleDuplicateGame(game.id)}
                onDelete={() => setShowDeleteDialog(game.id)}
              />
            ))}
          </div>
        ) : (
          <div className="space-y-4">
            {filteredGames.map((game) => (
              <Card key={game.id} className="overflow-hidden">
                <div className="flex flex-col sm:flex-row">
                  <div className="p-4 flex-1">
                    <div className="flex flex-col sm:flex-row sm:items-center gap-2 mb-2">
                      <h3 className="font-semibold">{game.title}</h3>
                      <div className="text-xs px-2 py-1 rounded-full bg-gray-100 w-fit">
                        {game.status === "completed" ? "Completed" : "Upcoming"}
                      </div>
                      {game.theme && (
                        <div className="text-xs px-2 py-1 rounded-full bg-blue-100 text-blue-800 w-fit">
                          {game.theme}
                        </div>
                      )}
                    </div>
                    <div className="flex flex-col sm:flex-row gap-4 text-sm text-muted-foreground">
                      <div className="flex items-center gap-1">
                        <Calendar className="h-4 w-4" />
                        <span>{formatDate(game.date)}</span>
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="h-4 w-4" />
                        <span>
                          {new Date(game.date).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                        </span>
                      </div>
                      <div className="flex items-center gap-1">
                        <MapPin className="h-4 w-4" />
                        <span>{game.location}</span>
                      </div>
                    </div>
                    {(game.titleSponsor || game.broadcastNetwork || game.giveaway) && (
                      <div className="mt-2 flex flex-wrap gap-2">
                        {game.titleSponsor && (
                          <span className="text-xs text-muted-foreground">Presented by {game.titleSponsor}</span>
                        )}
                        {game.broadcastNetwork && (
                          <span className="text-xs text-muted-foreground">TV: {game.broadcastNetwork}</span>
                        )}
                        {game.giveaway && (
                          <span className="text-xs text-muted-foreground">Giveaway: {game.giveaway}</span>
                        )}
                      </div>
                    )}
                  </div>
                  <div className="flex sm:flex-col justify-end items-center gap-2 p-4 bg-gray-50 border-t sm:border-t-0 sm:border-l">
                    <Link href={`/seasons/${seasonId}/games/${game.id}`}>
                      <Button variant="outline" size="sm" className="w-full flex items-center gap-1">
                        <FileText className="h-4 w-4" />
                        <span className="hidden sm:inline">Show-Flow</span>
                      </Button>
                    </Link>
                    <Link href={`/seasons/${seasonId}/games/${game.id}?view=timeline`}>
                      <Button variant="outline" size="sm" className="w-full flex items-center gap-1">
                        <LayoutTemplate className="h-4 w-4" />
                        <span className="hidden sm:inline">Timeline</span>
                      </Button>
                    </Link>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full flex items-center gap-1"
                      onClick={() => handleDuplicateGame(game.id)}
                    >
                      <Copy className="h-4 w-4" />
                      <span className="hidden sm:inline">Duplicate</span>
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      className="w-full flex items-center gap-1 text-red-500 hover:text-red-600"
                      onClick={() => setShowDeleteDialog(game.id)}
                    >
                      <Trash className="h-4 w-4" />
                      <span className="hidden sm:inline">Delete</span>
                    </Button>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        )}

        {/* Add Game button with dropdown */}
        <div className="mt-6">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button className="flex items-center gap-2">
                <Plus className="h-4 w-4" />
                Add Game
                <ChevronDown className="h-4 w-4 ml-1" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={() => setShowAddGameDialog(true)}>Add Single Game</DropdownMenuItem>
              <DropdownMenuItem onClick={() => setShowBatchAddGamesDialog(true)}>Add Multiple Games</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <AddGameDialog
            open={showAddGameDialog}
            onOpenChange={setShowAddGameDialog}
            seasonId={seasonId}
            onGameAdded={handleGameAdded}
          />

          <BatchAddGamesDialog
            open={showBatchAddGamesDialog}
            onOpenChange={setShowBatchAddGamesDialog}
            seasonId={seasonId}
            onGamesAdded={handleGamesAdded}
          />
        </div>
      </div>

      {/* Activity Feed */}
      <div className="mt-10">
        <h2 className="text-xl font-semibold mb-4">Recent Activity</h2>
        <Card>
          <CardContent className="p-0">
            <ActivityFeed activities={activities} />
          </CardContent>
          <CardFooter className="border-t p-4">
            <Button variant="link" className="p-0">
              View All Activity
            </Button>
          </CardFooter>
        </Card>
      </div>

      {/* Delete Confirmation Dialog */}
      <Dialog open={!!showDeleteDialog} onOpenChange={(open) => !open && setShowDeleteDialog(null)}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Confirm Deletion</DialogTitle>
          </DialogHeader>
          <p>Are you sure you want to delete this game? This action cannot be undone.</p>
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowDeleteDialog(null)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={() => showDeleteDialog && handleDeleteGame(showDeleteDialog)}>
              Delete Game
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </main>
  )
}

