import { createClient } from "@supabase/supabase-js"
import type {
  Season,
  Game,
  ShowFlowItem,
  Component,
  Asset,
  EventComponent,
  ShowFlowAsset,
  Activity,
  TimelineEvent,
} from "./types"

// Update the Supabase client initialization at the top of the file
// Replace:
// With:
const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL
const supabaseKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY
let supabase: ReturnType<typeof createClient> | null = null

// Only create the client if both URL and key are available
if (supabaseUrl && supabaseKey) {
  try {
    supabase = createClient(supabaseUrl, supabaseKey)
    console.log("Supabase client initialized successfully")
  } catch (error) {
    console.error("Error initializing Supabase client:", error)
    supabase = null
  }
} else {
  console.warn("Supabase URL or key not provided. Using localStorage fallbacks.")
}

// Helper function to check if Supabase is available
function isSupabaseAvailable() {
  return !!supabase
}

// Seasons
export async function getSeasons(): Promise<Season[]> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")

      // Try to get mock seasons from localStorage first
      const mockSeasonsFromStorage = JSON.parse(localStorage.getItem("mockSeasons") || "[]")

      if (mockSeasonsFromStorage.length > 0) {
        console.log("Retrieved mock seasons from localStorage:", mockSeasonsFromStorage)
        return mockSeasonsFromStorage
      }

      // If no mock seasons in localStorage, return default mock data
      const mockSeasons = [
        {
          id: crypto.randomUUID ? crypto.randomUUID() : "season-1",
          title: "NFL 2023",
          sport: "Football",
          year: 2023,
          description: "Regular season games for NFL 2023",
          status: "in-progress",
          gameCount: 0,
          completedGames: 0,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: crypto.randomUUID ? crypto.randomUUID() : "season-2",
          title: "NBA 2023-2024",
          sport: "Basketball",
          year: 2023,
          description: "NBA regular season",
          status: "draft",
          gameCount: 0,
          completedGames: 0,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ]

      // Save these to localStorage for future use
      localStorage.setItem("mockSeasons", JSON.stringify(mockSeasons))

      return mockSeasons
    }

    // First, check if the seasons table exists
    const { error: checkError } = await supabase!.from("seasons").select("id").limit(1)

    // If the table doesn't exist, use mock data
    if (checkError && checkError.message.includes("does not exist")) {
      console.warn("Seasons table does not exist. Using mock data instead.")

      // Try to get mock seasons from localStorage first
      const mockSeasonsFromStorage = JSON.parse(localStorage.getItem("mockSeasons") || "[]")

      if (mockSeasonsFromStorage.length > 0) {
        console.log("Retrieved mock seasons from localStorage:", mockSeasonsFromStorage)
        return mockSeasonsFromStorage
      }

      // If no mock seasons in localStorage, return default mock data
      const mockSeasons = [
        {
          id: crypto.randomUUID ? crypto.randomUUID() : "season-1",
          title: "NFL 2023",
          sport: "Football",
          year: 2023,
          description: "Regular season games for NFL 2023",
          status: "in-progress",
          gameCount: 0,
          completedGames: 0,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
        {
          id: crypto.randomUUID ? crypto.randomUUID() : "season-2",
          title: "NBA 2023-2024",
          sport: "Basketball",
          year: 2023,
          description: "NBA regular season",
          status: "draft",
          gameCount: 0,
          completedGames: 0,
          createdAt: new Date().toISOString(),
          updatedAt: new Date().toISOString(),
        },
      ]

      // Save these to localStorage for future use
      localStorage.setItem("mockSeasons", JSON.stringify(mockSeasons))

      return mockSeasons
    }

    // If the table exists, fetch the data normally
    const { data, error } = await supabase!.from("seasons").select("*").order("year", { ascending: false })

    if (error) {
      console.error("Error fetching seasons:", error)
      throw new Error(error.message)
    }

    // Convert snake_case to camelCase
    return (data || []).map((season) => ({
      id: season.id,
      title: season.title,
      sport: season.sport,
      year: season.year,
      createdAt: season.created_at,
      updatedAt: season.updated_at,
      description: season.description,
      status: season.status,
    }))
  } catch (error) {
    console.error("Error in getSeasons:", error)

    // Try to get mock seasons from localStorage first
    const mockSeasonsFromStorage = JSON.parse(localStorage.getItem("mockSeasons") || "[]")

    if (mockSeasonsFromStorage.length > 0) {
      console.log("Retrieved mock seasons from localStorage after error:", mockSeasonsFromStorage)
      return mockSeasonsFromStorage
    }

    // Return mock data as fallback
    const mockSeasons = [
      {
        id: crypto.randomUUID ? crypto.randomUUID() : "season-1",
        title: "NFL 2023",
        sport: "Football",
        year: 2023,
        description: "Regular season games for NFL 2023",
        status: "in-progress",
        gameCount: 0,
        completedGames: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      {
        id: crypto.randomUUID ? crypto.randomUUID() : "season-2",
        title: "NBA 2023-2024",
        sport: "Basketball",
        year: 2023,
        description: "NBA regular season",
        status: "draft",
        gameCount: 0,
        completedGames: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
    ]

    // Save these to localStorage for future use
    localStorage.setItem("mockSeasons", JSON.stringify(mockSeasons))

    return mockSeasons
  }
}

// Update the createSeason function to ensure proper ID handling and persistence
export async function createSeason(season: Omit<Season, "id">): Promise<Season> {
  try {
    console.log("Creating new season:", season)

    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")

      // Generate a unique ID for the mock season - using UUID format
      const mockId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
      console.log(`Generated mock ID: ${mockId}`)

      // Create a mock season object
      const mockSeason = {
        id: mockId,
        title: season.title,
        sport: season.sport,
        year: season.year,
        description: season.description,
        status: season.status || "draft",
        gameCount: 0,
        completedGames: 0,
        createdAt: season.createdAt || new Date().toISOString(),
        updatedAt: season.updatedAt || new Date().toISOString(),
      }

      // Store the mock season in localStorage to persist it between page loads
      const existingSeasons = JSON.parse(localStorage.getItem("mockSeasons") || "[]")
      existingSeasons.push(mockSeason)
      localStorage.setItem("mockSeasons", JSON.stringify(existingSeasons))

      console.log("Saved mock season to localStorage:", mockSeason)
      return mockSeason
    }

    // Check if the seasons table exists
    const { error: checkError } = await supabase!.from("seasons").select("id").limit(1)

    // If the table doesn't exist, return mock data
    if (checkError && checkError.message.includes("does not exist")) {
      console.warn("Seasons table does not exist. Creating mock season.")

      // Generate a unique ID for the mock season - using UUID format
      const mockId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
      console.log(`Generated mock ID: ${mockId}`)

      // Create a mock season object
      const mockSeason = {
        id: mockId,
        title: season.title,
        sport: season.sport,
        year: season.year,
        description: season.description,
        status: season.status || "draft",
        gameCount: 0,
        completedGames: 0,
        createdAt: season.createdAt || new Date().toISOString(),
        updatedAt: season.updatedAt || new Date().toISOString(),
      }

      // Store the mock season in localStorage to persist it between page loads
      const existingSeasons = JSON.parse(localStorage.getItem("mockSeasons") || "[]")
      existingSeasons.push(mockSeason)
      localStorage.setItem("mockSeasons", JSON.stringify(existingSeasons))

      console.log("Saved mock season to localStorage:", mockSeason)
      return mockSeason
    }

    // Convert camelCase to snake_case for Supabase
    const { data, error } = await supabase!
      .from("seasons")
      .insert([
        {
          title: season.title,
          sport: season.sport,
          year: season.year,
          description: season.description,
          status: season.status || "draft",
          created_at: season.createdAt || new Date().toISOString(),
          updated_at: season.updatedAt || new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Error creating season:", error)
      throw new Error(error.message)
    }

    console.log("Season created successfully:", data)

    // Convert snake_case back to camelCase
    return {
      id: data.id,
      title: data.title,
      sport: data.sport,
      year: data.year,
      description: data.description,
      status: data.status,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    }
  } catch (error) {
    console.error("Error in createSeason:", error)

    // Generate a unique ID for the mock season - using UUID format
    const mockId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
    console.log(`Generated mock ID after error: ${mockId}`)

    // Create a mock season object
    const mockSeason = {
      id: mockId,
      title: season.title,
      sport: season.sport,
      year: season.year,
      description: season.description,
      status: season.status || "draft",
      gameCount: 0,
      completedGames: 0,
      createdAt: season.createdAt || new Date().toISOString(),
      updatedAt: season.updatedAt || new Date().toISOString(),
    }

    // Store the mock season in localStorage to persist it between page loads
    const existingSeasons = JSON.parse(localStorage.getItem("mockSeasons") || "[]")
    existingSeasons.push(mockSeason)
    localStorage.setItem("mockSeasons", JSON.stringify(existingSeasons))

    console.log("Saved mock season to localStorage after error:", mockSeason)
    return mockSeason
  }
}

// Update the getSeason function to better handle IDs and provide more debugging
export async function getSeason(id: string): Promise<Season | null> {
  try {
    console.log(`Fetching season with ID: ${id}`)

    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      console.log("Seasons table does not exist, checking localStorage for mock data")

      // Try to get mock seasons from localStorage
      const mockSeasonsFromStorage = JSON.parse(localStorage.getItem("mockSeasons") || "[]")
      const mockSeason = mockSeasonsFromStorage.find((s: Season) => s.id === id)

      if (mockSeason) {
        console.log("Found mock season in localStorage:", mockSeason)
        return mockSeason
      }

      // If not found in localStorage, return a generated mock season
      console.log("Creating new mock season for ID:", id)
      return {
        id: id,
        title: `Season ${id.substring(0, 8)}`,
        sport: "Football",
        year: 2023,
        description: "This is a mock season for development",
        status: "in-progress",
        gameCount: 0,
        completedGames: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    }

    // Check if the seasons table exists
    const { error: checkError } = await supabase!.from("seasons").select("id").limit(1)

    if (checkError && checkError.message.includes("does not exist")) {
      console.log("Seasons table does not exist, checking localStorage for mock data")

      // Try to get mock seasons from localStorage
      const mockSeasonsFromStorage = JSON.parse(localStorage.getItem("mockSeasons") || "[]")
      const mockSeason = mockSeasonsFromStorage.find((s: Season) => s.id === id)

      if (mockSeason) {
        console.log("Found mock season in localStorage:", mockSeason)
        return mockSeason
      }

      // If not found in localStorage, return a generated mock season
      console.log("Creating new mock season for ID:", id)
      return {
        id: id,
        title: `Season ${id.substring(0, 8)}`,
        sport: "Football",
        year: 2023,
        description: "This is a mock season for development",
        status: "in-progress",
        gameCount: 0,
        completedGames: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    }

    const { data, error } = await supabase!.from("seasons").select("*").eq("id", id).single()

    if (error) {
      console.error(`Error fetching season with ID ${id}:`, error)

      // Check localStorage for mock seasons
      const mockSeasonsFromStorage = JSON.parse(localStorage.getItem("mockSeasons") || "[]")
      const mockSeason = mockSeasonsFromStorage.find((s: Season) => s.id === id)

      if (mockSeason) {
        console.log("Found mock season in localStorage after DB error:", mockSeason)
        return mockSeason
      }

      // If no match is found, return mock data based on the ID
      return {
        id: id,
        title: `Season ${id.substring(0, 8)}`,
        sport: "Football",
        year: 2023,
        description: "Auto-generated season data",
        status: "in-progress",
        gameCount: 0,
        completedGames: 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }
    }

    console.log("Season data retrieved:", data)

    // Convert snake_case to camelCase
    return data
      ? {
          id: data.id,
          title: data.title,
          sport: data.sport,
          year: data.year,
          createdAt: data.created_at,
          updatedAt: data.updated_at,
          description: data.description,
          status: data.status,
        }
      : null
  } catch (error) {
    console.error("Error in getSeason:", error)

    // Check localStorage for mock seasons
    const mockSeasonsFromStorage = JSON.parse(localStorage.getItem("mockSeasons") || "[]")
    const mockSeason = mockSeasonsFromStorage.find((s: Season) => s.id === id)

    if (mockSeason) {
      console.log("Found mock season in localStorage after error:", mockSeason)
      return mockSeason
    }

    // Return mock data for the requested ID as fallback
    return {
      id: id,
      title: `Season ${id.substring(0, 8)}`,
      sport: "Football",
      year: 2023,
      description: "Auto-generated season data",
      status: "in-progress",
      gameCount: 0,
      completedGames: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
  }
}

// Update the createGame function to ensure games are properly saved
export async function createGame(game: Omit<Game, "id" | "createdAt" | "updatedAt">): Promise<Game> {
  try {
    console.log("Creating new game:", game)

    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      // Generate a unique ID for the game - using UUID format
      const gameId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)

      // Create a complete game object with the user's data
      const newGame = {
        id: gameId,
        seasonId: game.seasonId,
        title: game.title,
        date: game.date,
        eventStartTime: game.eventStartTime,
        location: game.location,
        theme: game.theme,
        titleSponsor: game.titleSponsor,
        broadcastNetwork: game.broadcastNetwork,
        giveaway: game.giveaway,
        status: game.status || "upcoming",
        eventCount: game.eventCount || 0,
        completedEvents: game.completedEvents || 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      // Store in localStorage
      const existingGames = JSON.parse(localStorage.getItem("games") || "[]")
      existingGames.push(newGame)
      localStorage.setItem("games", JSON.stringify(existingGames))

      console.log("Saved game to localStorage:", newGame)
      return newGame
    }

    // Check if the games table exists
    const { error: checkError } = await supabase!.from("games").select("id").limit(1)

    // If the table doesn't exist, save to localStorage
    if (checkError && checkError.message && checkError.message.includes("does not exist")) {
      console.warn("Games table does not exist. Saving to localStorage instead.")

      // Generate a unique ID for the game - using UUID format
      const gameId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)

      // Create a complete game object with the user's data
      const newGame = {
        id: gameId,
        seasonId: game.seasonId,
        title: game.title,
        date: game.date,
        eventStartTime: game.eventStartTime,
        location: game.location,
        theme: game.theme,
        titleSponsor: game.titleSponsor,
        broadcastNetwork: game.broadcastNetwork,
        giveaway: game.giveaway,
        status: game.status || "upcoming",
        eventCount: game.eventCount || 0,
        completedEvents: game.completedEvents || 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      // Store in localStorage
      const existingGames = JSON.parse(localStorage.getItem("games") || "[]")
      existingGames.push(newGame)
      localStorage.setItem("games", JSON.stringify(existingGames))

      console.log("Saved game to localStorage:", newGame)
      return newGame
    }

    // Try to insert into Supabase
    const { data, error } = await supabase!
      .from("games")
      .insert([
        {
          season_id: game.seasonId,
          title: game.title,
          date: game.date,
          event_start_time: game.eventStartTime,
          location: game.location,
          theme: game.theme,
          title_sponsor: game.titleSponsor,
          broadcast_network: game.broadcastNetwork,
          giveaway: game.giveaway,
          status: game.status || "upcoming",
          event_count: game.eventCount || 0,
          completed_events: game.completedEvents || 0,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Error creating game in Supabase:", error)

      // Save to localStorage as fallback
      const gameId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
      const newGame = {
        id: gameId,
        seasonId: game.seasonId,
        title: game.title,
        date: game.date,
        eventStartTime: game.eventStartTime,
        location: game.location,
        theme: game.theme,
        titleSponsor: game.titleSponsor,
        broadcastNetwork: game.broadcastNetwork,
        giveaway: game.giveaway,
        status: game.status || "upcoming",
        eventCount: game.eventCount || 0,
        completedEvents: game.completedEvents || 0,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      const existingGames = JSON.parse(localStorage.getItem("games") || "[]")
      existingGames.push(newGame)
      localStorage.setItem("games", JSON.stringify(existingGames))

      console.log("Saved game to localStorage after Supabase error:", newGame)
      return newGame
    }

    // Convert snake_case to camelCase
    const newGame = {
      id: data.id,
      seasonId: data.season_id,
      title: data.title,
      date: data.date,
      eventStartTime: data.event_start_time,
      location: data.location,
      theme: data.theme,
      titleSponsor: data.title_sponsor,
      broadcastNetwork: data.broadcast_network,
      giveaway: data.giveaway,
      status: data.status,
      eventCount: data.event_count,
      completedEvents: data.completed_events,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    }

    console.log("Game created successfully:", newGame)
    return newGame
  } catch (error) {
    console.error("Error in createGame:", error)

    // Save to localStorage as fallback
    const gameId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
    const newGame = {
      id: gameId,
      seasonId: game.seasonId,
      title: game.title,
      date: game.date,
      eventStartTime: game.eventStartTime,
      location: game.location,
      theme: game.theme,
      titleSponsor: game.titleSponsor,
      broadcastNetwork: game.broadcastNetwork,
      giveaway: game.giveaway,
      status: game.status || "upcoming",
      eventCount: game.eventCount || 0,
      completedEvents: game.completedEvents || 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    const existingGames = JSON.parse(localStorage.getItem("games") || "[]")
    existingGames.push(newGame)
    localStorage.setItem("games", JSON.stringify(existingGames))

    console.log("Saved game to localStorage after exception:", newGame)
    return newGame
  }
}

// Update other ID generation in the file
// Let's also improve the createShowFlowItem function to be more robust:

// 1. Find the createShowFlowItem function and replace it with:
export async function createShowFlowItem(
  item: Omit<ShowFlowItem, "id" | "createdAt" | "updatedAt">,
): Promise<ShowFlowItem> {
  console.log("createShowFlowItem called with:", item)

  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")

      // Generate a unique ID
      const id = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
      console.log("Generated mock ID:", id)

      // Create a complete item with the generated ID
      const mockItem: ShowFlowItem = {
        id,
        gameId: item.gameId,
        itemNumber: item.itemNumber,
        startTime: item.startTime,
        presetTime: item.presetTime,
        duration: item.duration,
        privateNotes: item.privateNotes,
        clockRef: item.clockRef,
        location: item.location,
        audioNotes: item.audioNotes,
        scriptRead: item.scriptRead,
        boardLook: item.boardLook,
        main: item.main,
        aux: item.aux,
        lowerThird: item.lowerThird,
        ribbon: item.ribbon,
        controlRoom: item.controlRoom,
        category: item.category,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      // Store in localStorage
      const existingItems = JSON.parse(localStorage.getItem("showFlowItems") || "[]")
      existingItems.push(mockItem)
      localStorage.setItem("showFlowItems", JSON.stringify(existingItems))

      console.log("Created mock item:", mockItem)
      return mockItem
    }

    // Check if the show_flow_items table exists
    const { error: checkError } = await supabase!.from("show_flow_items").select("id").limit(1)

    if (checkError && checkError.message.includes("does not exist")) {
      console.warn("show_flow_items table does not exist. Using mock data instead.")

      // Generate a unique ID
      const id = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
      console.log("Generated mock ID after table check:", id)

      // Create a complete item with the generated ID
      const mockItem: ShowFlowItem = {
        id,
        gameId: item.gameId,
        itemNumber: item.itemNumber,
        startTime: item.startTime,
        presetTime: item.presetTime,
        duration: item.duration,
        privateNotes: item.privateNotes,
        clockRef: item.clockRef,
        location: item.location,
        audioNotes: item.audioNotes,
        scriptRead: item.scriptRead,
        boardLook: item.boardLook,
        main: item.main,
        aux: item.aux,
        lowerThird: item.lowerThird,
        ribbon: item.ribbon,
        controlRoom: item.controlRoom,
        category: item.category,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      // Store in localStorage
      const existingItems = JSON.parse(localStorage.getItem("showFlowItems") || "[]")
      existingItems.push(mockItem)
      localStorage.setItem("showFlowItems", JSON.stringify(existingItems))

      console.log("Created mock item after table check:", mockItem)
      return mockItem
    }

    // Try to insert into Supabase
    const { data, error } = await supabase!
      .from("show_flow_items")
      .insert([
        {
          game_id: item.gameId,
          item_number: item.itemNumber,
          start_time: item.startTime,
          preset_time: item.presetTime,
          duration: item.duration,
          private_notes: item.privateNotes,
          clock_ref: item.clockRef,
          location: item.location,
          audio_notes: item.audioNotes,
          script_read: item.scriptRead,
          board_look: item.boardLook,
          main: item.main,
          aux: item.aux,
          lower_third: item.lowerThird,
          ribbon: item.ribbon,
          control_room: item.controlRoom,
          category: item.category,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Error inserting into Supabase:", error)

      // Generate a unique ID for fallback
      const id = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
      console.log("Generated fallback ID after Supabase error:", id)

      // Create a fallback item
      const fallbackItem: ShowFlowItem = {
        id,
        gameId: item.gameId,
        itemNumber: item.itemNumber,
        startTime: item.startTime,
        presetTime: item.presetTime,
        duration: item.duration,
        privateNotes: item.privateNotes,
        clockRef: item.clockRef,
        location: item.location,
        audioNotes: item.audioNotes,
        scriptRead: item.scriptRead,
        boardLook: item.boardLook,
        main: item.main,
        aux: item.aux,
        lowerThird: item.lowerThird,
        ribbon: item.ribbon,
        controlRoom: item.controlRoom,
        category: item.category,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      }

      // Store in localStorage
      const existingItems = JSON.parse(localStorage.getItem("showFlowItems") || "[]")
      existingItems.push(fallbackItem)
      localStorage.setItem("showFlowItems", JSON.stringify(existingItems))

      console.log("Created fallback item after Supabase error:", fallbackItem)
      return fallbackItem
    }

    // Convert snake_case to camelCase
    const createdItem: ShowFlowItem = {
      id: data.id,
      gameId: data.game_id,
      itemNumber: data.item_number,
      startTime: data.start_time,
      presetTime: data.preset_time,
      duration: data.duration,
      privateNotes: data.private_notes,
      clockRef: data.clock_ref,
      location: data.location,
      audioNotes: data.audio_notes,
      scriptRead: data.script_read,
      boardLook: data.board_look,
      main: data.main,
      aux: data.aux,
      lowerThird: data.lower_third,
      ribbon: data.ribbon,
      controlRoom: data.control_room,
      category: data.category,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    }

    console.log("Successfully created item in Supabase:", createdItem)
    return createdItem
  } catch (error) {
    console.error("Exception in createShowFlowItem:", error)

    // Generate a unique ID for fallback
    const id = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
    console.log("Generated fallback ID after exception:", id)

    // Create a fallback item
    const fallbackItem: ShowFlowItem = {
      id,
      gameId: item.gameId,
      itemNumber: item.itemNumber,
      startTime: item.startTime,
      presetTime: item.presetTime,
      duration: item.duration,
      privateNotes: item.privateNotes,
      clockRef: item.clockRef,
      location: item.location,
      audioNotes: item.audioNotes,
      scriptRead: item.scriptRead,
      boardLook: item.boardLook,
      main: item.main,
      aux: item.aux,
      lowerThird: item.lowerThird,
      ribbon: item.ribbon,
      controlRoom: item.controlRoom,
      category: item.category,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }

    // Store in localStorage
    const existingItems = JSON.parse(localStorage.getItem("showFlowItems") || "[]")
    existingItems.push(fallbackItem)
    localStorage.setItem("showFlowItems", JSON.stringify(existingItems))

    console.log("Created fallback item after exception:", fallbackItem)
    return fallbackItem
  }
}

// Update uploadAsset function
export async function uploadAsset(file: File, path: string): Promise<Asset> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      // Return mock data with UUID
      return {
        id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
        fileName: file.name,
        fileType: file.type,
        fileSizeBytes: file.size,
        url: URL.createObjectURL(file),
        uploadedAt: new Date().toISOString(),
      }
    }

    // Upload to Supabase Storage
    const { data: uploadData, error: uploadError } = await supabase!.storage.from("scriptman-assets").upload(path, file)

    if (uploadError) {
      if (uploadError.message.includes("does not exist")) {
        // Return mock data with UUID
        return {
          id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
          fileName: file.name,
          fileType: file.type,
          fileSizeBytes: file.size,
          url: URL.createObjectURL(file),
          uploadedAt: new Date().toISOString(),
        }
      }
      throw uploadError
    }

    // Get public URL
    const {
      data: { publicUrl },
    } = supabase!.storage.from("scriptman-assets").getPublicUrl(uploadData.path)

    // Create asset record
    const { data, error } = await supabase!
      .from("assets")
      .insert([
        {
          file_name: file.name,
          file_type: file.type,
          file_size_bytes: file.size,
          url: publicUrl,
        },
      ])
      .select()
      .single()

    if (error) {
      if (error.message.includes("does not exist")) {
        // Return mock data with UUID
        return {
          id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
          fileName: file.name,
          fileType: file.type,
          fileSizeBytes: file.size,
          url: publicUrl,
          uploadedAt: new Date().toISOString(),
        }
      }
      throw error
    }
    return data
  } catch (error) {
    console.error("Error uploading asset:", error)
    // Return mock data with UUID
    return {
      id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
      fileName: file.name,
      fileType: file.type,
      fileSizeBytes: file.size,
      url: URL.createObjectURL(file),
      uploadedAt: new Date().toISOString(),
    }
  }
}

// Update linkComponentToShowFlow function
export async function linkComponentToShowFlow(showFlowId: string, componentId: string): Promise<EventComponent> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      // Return mock data with UUID
      return {
        id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
        showFlowId,
        componentId,
      }
    }

    const { data, error } = await supabase!
      .from("event_components")
      .insert([
        {
          show_flow_id: showFlowId,
          component_id: componentId,
        },
      ])
      .select()
      .single()

    if (error) {
      if (error.message.includes("does not exist")) {
        // Return mock data with UUID
        return {
          id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
          showFlowId,
          componentId,
        }
      }
      throw error
    }
    return data
  } catch (error) {
    console.error("Error linking component to show flow:", error)
    // Return mock data with UUID
    return {
      id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
      showFlowId,
      componentId,
    }
  }
}

// Update linkAssetToShowFlow function
export async function linkAssetToShowFlow(showFlowId: string, assetId: string): Promise<ShowFlowAsset> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      // Return mock data with UUID
      return {
        id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
        showFlowId,
        assetId,
      }
    }

    const { data, error } = await supabase!
      .from("show_flow_assets")
      .insert([
        {
          show_flow_id: showFlowId,
          asset_id: assetId,
        },
      ])
      .select()
      .single()

    if (error) {
      if (error.message.includes("does not exist")) {
        // Return mock data with UUID
        return {
          id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
          showFlowId,
          assetId,
        }
      }
      throw error
    }
    return data
  } catch (error) {
    console.error("Error linking asset to show flow:", error)
    // Return mock data with UUID
    return {
      id: crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15),
      showFlowId,
      assetId,
    }
  }
}

export async function updateSeason(id: string, updates: Partial<Season>): Promise<Season> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      throw new Error("Supabase client not initialized. Cannot update season.")
    }

    const { data, error } = await supabase!
      .from("seasons")
      .update({
        title: updates.title,
        sport: updates.sport,
        year: updates.year,
        description: updates.description,
        status: updates.status,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("Error updating season:", error)
      throw new Error(error.message)
    }

    return {
      id: data.id,
      title: data.title,
      sport: data.sport,
      year: data.year,
      description: data.description,
      status: data.status,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    }
  } catch (error) {
    console.error("Error in updateSeason:", error)
    throw error
  }
}

export async function deleteSeason(id: string): Promise<void> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Cannot delete season.")
      return
    }

    const { error } = await supabase!.from("seasons").delete().eq("id", id)

    if (error) {
      console.error("Error deleting season:", error)
      throw new Error(error.message)
    }
  } catch (error) {
    console.error("Error in deleteSeason:", error)
    throw error
  }
}

// Update the getGames function to properly retrieve games from localStorage
export async function getGames(seasonId: string): Promise<Game[]> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      console.warn("Games table does not exist. Using localStorage instead.")

      // Get games from localStorage
      const gamesFromStorage = JSON.parse(localStorage.getItem("games") || "[]")
      console.log(`Retrieved ${gamesFromStorage.length} games from localStorage`)

      // Filter games by seasonId
      const seasonGames = gamesFromStorage.filter((g: Game) => g.seasonId === seasonId)
      console.log(`Found ${seasonGames.length} games for season ${seasonId}`)

      return seasonGames
    }

    // First, check if the games table exists
    const { error: checkError } = await supabase!.from("games").select("id").limit(1)

    // If the table doesn't exist, use localStorage
    if (checkError && checkError.message.includes("does not exist")) {
      console.warn("Games table does not exist. Using localStorage instead.")

      // Get games from localStorage
      const gamesFromStorage = JSON.parse(localStorage.getItem("games") || "[]")
      console.log(`Retrieved ${gamesFromStorage.length} games from localStorage`)

      // Filter games by seasonId
      const seasonGames = gamesFromStorage.filter((g: Game) => g.seasonId === seasonId)
      console.log(`Found ${seasonGames.length} games for season ${seasonId}`)

      return seasonGames
    }

    // If the table exists, fetch the data normally
    const { data, error } = await supabase!
      .from("games")
      .select("*")
      .eq("season_id", seasonId)
      .order("date", { ascending: true })

    if (error) {
      console.error("Error fetching games:", error)

      // Try localStorage as fallback
      const gamesFromStorage = JSON.parse(localStorage.getItem("games") || "[]")
      const seasonGames = gamesFromStorage.filter((g: Game) => g.seasonId === seasonId)
      console.log(`Retrieved ${seasonGames.length} games from localStorage after DB error`)

      return seasonGames
    }

    return (data || []).map((game) => ({
      id: game.id,
      seasonId: game.season_id,
      title: game.title,
      date: game.date,
      eventStartTime: game.event_start_time,
      location: game.location,
      theme: game.theme,
      titleSponsor: game.titleSponsor,
      broadcastNetwork: game.broadcastNetwork,
      giveaway: game.giveaway,
      status: game.status,
      eventCount: game.event_count,
      completedEvents: game.completed_events,
      createdAt: game.created_at,
      updatedAt: game.updated_at,
    }))
  } catch (error) {
    console.error("Error in getGames:", error)

    // Try localStorage as fallback
    const gamesFromStorage = JSON.parse(localStorage.getItem("games") || "[]")
    const seasonGames = gamesFromStorage.filter((g: Game) => g.seasonId === seasonId)
    console.log(`Retrieved ${seasonGames.length} games from localStorage after exception`)

    return seasonGames
  }
}

export async function deleteGame(id: string): Promise<void> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Cannot delete game.")
      return
    }

    const { error } = await supabase!.from("games").delete().eq("id", id)

    if (error) {
      console.error("Error deleting game:", error)
      throw new Error(error.message)
    }
  } catch (error) {
    console.error("Error in deleteGame:", error)
    throw error
  }
}

// Also update the getActivities function to handle the "relation does not exist" error
export async function getActivities(limit: number): Promise<Activity[]> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Returning empty array.")
      return []
    }

    // Check if the activities table exists
    const { error: checkError } = await supabase!.from("activities").select("id").limit(1)

    if (checkError && checkError.message.includes("does not exist")) {
      console.warn("Activities table does not exist. Returning empty array.")
      return []
    }

    const { data, error } = await supabase!
      .from("activities")
      .select("*")
      .order("timestamp", { ascending: false })
      .limit(limit)

    if (error) {
      console.error("Error fetching activities:", error)
      return []
    }

    return (data || []).map((activity) => ({
      id: activity.id,
      action: activity.action,
      timestamp: activity.timestamp,
      user: activity.user,
      entityId: activity.entity_id,
      entityType: activity.entity_type,
    }))
  } catch (error) {
    console.error("Error in getActivities:", error)
    return []
  }
}

// Update the getGame function to properly retrieve a game from localStorage
export async function getGame(id: string): Promise<Game | null> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      console.warn("Games table does not exist. Using localStorage instead.")

      // Get games from localStorage
      const gamesFromStorage = JSON.parse(localStorage.getItem("games") || "[]")

      // Find the game by id
      const game = gamesFromStorage.find((g: Game) => g.id === id)
      console.log(game ? `Found game ${id} in localStorage` : `Game ${id} not found in localStorage`)

      return game || null
    }

    // Check if the games table exists
    const { error: checkError } = await supabase!.from("games").select("id").limit(1)

    if (checkError && checkError.message.includes("does not exist")) {
      console.warn("Games table does not exist. Using localStorage instead.")

      // Get games from localStorage
      const gamesFromStorage = JSON.parse(localStorage.getItem("games") || "[]")

      // Find the game by id
      const game = gamesFromStorage.find((g: Game) => g.id === id)
      console.log(game ? `Found game ${id} in localStorage` : `Game ${id} not found in localStorage`)

      return game || null
    }

    const { data, error } = await supabase!.from("games").select("*").eq("id", id).single()

    if (error) {
      console.error("Error fetching game:", error)

      // Try localStorage as fallback
      const gamesFromStorage = JSON.parse(localStorage.getItem("games") || "[]")
      const game = gamesFromStorage.find((g: Game) => g.id === id)
      console.log(
        game
          ? `Found game ${id} in localStorage after DB error`
          : `Game ${id} not found in localStorage after DB error`,
      )

      return game || null
    }

    if (!data) {
      return null
    }

    return {
      id: data.id,
      seasonId: data.season_id,
      title: data.title,
      date: data.date,
      eventStartTime: data.event_start_time,
      location: data.location,
      theme: data.theme,
      titleSponsor: data.title_sponsor,
      broadcastNetwork: data.broadcast_network,
      giveaway: data.giveaway,
      status: data.status,
      eventCount: data.event_count,
      completedEvents: data.completed_events,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    }
  } catch (error) {
    console.error("Error in getGame:", error)

    // Try localStorage as fallback
    const gamesFromStorage = JSON.parse(localStorage.getItem("games") || "[]")
    const game = gamesFromStorage.find((g: Game) => g.id === id)
    console.log(
      game
        ? `Found game ${id} in localStorage after exception`
        : `Game ${id} not found in localStorage after exception`,
    )

    return game || null
  }
}

export async function getComponent(name: string): Promise<Component | null> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      console.log(`Generating mock component for: ${name}`)

      const mockComponent: Component = {
        id: "component-1",
        name: name,
        type: "Graphics",
        version: 1,
        isGlobal: true,
        description: "A sample graphics component",
        content: "<h1>Sample Graphics</h1>",
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
        assets: [
          {
            id: "asset-1",
            fileName: "sample-image.jpg",
            fileType: "image/jpeg",
            fileSizeBytes: 1024 * 1024, // 1MB
            url: "/placeholder.svg?height=300&width=400",
            uploadedAt: new Date().toISOString(),
          },
        ],
      }

      return mockComponent
    }

    // In a real implementation, this would fetch from the database
    // For now, return mock data for testing
    console.log(`Generating mock component for: ${name}`)

    const mockComponent: Component = {
      id: "component-1",
      name: name,
      type: "Graphics",
      version: 1,
      isGlobal: true,
      description: "A sample graphics component",
      content: "<h1>Sample Graphics</h1>",
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      assets: [
        {
          id: "asset-1",
          fileName: "sample-image.jpg",
          fileType: "image/jpeg",
          fileSizeBytes: 1024 * 1024, // 1MB
          url: "/placeholder.svg?height=300&width=400",
          uploadedAt: new Date().toISOString(),
        },
      ],
    }

    return mockComponent
  } catch (error) {
    console.error("Error in getComponent:", error)
    return null
  }
}

// Update the getShowFlowItems function to handle the "relation does not exist" error
export async function getShowFlowItems(gameId: string): Promise<ShowFlowItem[]> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Returning empty array.")
      return []
    }

    // Check if the show_flow_items table exists
    const { error: checkError } = await supabase!.from("show_flow_items").select("id").limit(1)

    if (checkError && checkError.message.includes("does not exist")) {
      console.warn("Show flow items table does not exist. Returning empty array.")
      return []
    }

    const { data, error } = await supabase!
      .from("show_flow_items")
      .select("*")
      .eq("game_id", gameId)
      .order("item_number", { ascending: true })

    if (error) {
      console.error("Error fetching show flow items:", error)
      return []
    }

    return (data || []).map((item) => ({
      id: item.id,
      gameId: item.game_id,
      itemNumber: item.item_number,
      startTime: item.start_time,
      presetTime: item.preset_time,
      duration: item.duration,
      privateNotes: item.private_notes,
      clockRef: item.clock_ref,
      location: item.location,
      audioNotes: item.audio_notes,
      scriptRead: item.script_read,
      boardLook: item.board_look,
      main: item.main,
      aux: item.aux,
      lowerThird: item.lower_third,
      ribbon: item.ribbon,
      controlRoom: item.control_room,
      category: item.category,
      createdAt: item.created_at,
      updatedAt: item.updated_at,
    }))
  } catch (error) {
    console.error("Error in getShowFlowItems:", error)
    return []
  }
}

export async function updateShowFlowItem(id: string, updates: Partial<ShowFlowItem>): Promise<ShowFlowItem> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Cannot update show flow item.")
      throw new Error("Supabase client not initialized. Cannot update show flow item.")
    }

    const { data, error } = await supabase!
      .from("show_flow_items")
      .update({
        item_number: updates.itemNumber,
        start_time: updates.startTime,
        preset_time: updates.presetTime,
        duration: updates.duration,
        private_notes: updates.privateNotes,
        clock_ref: updates.clockRef,
        location: updates.location,
        audio_notes: updates.audioNotes,
        script_read: updates.scriptRead,
        board_look: updates.boardLook,
        main: updates.main,
        aux: updates.aux,
        lower_third: updates.lowerThird,
        ribbon: updates.ribbon,
        control_room: updates.controlRoom,
        category: updates.category,
        updated_at: new Date().toISOString(),
      })
      .eq("id", id)
      .select()
      .single()

    if (error) {
      console.error("Error updating show flow item:", error)
      throw new Error(error.message)
    }

    return {
      id: data.id,
      gameId: data.game_id,
      itemNumber: data.item_number,
      startTime: data.start_time,
      presetTime: data.preset_time,
      duration: data.duration,
      privateNotes: data.private_notes,
      clockRef: data.clock_ref,
      location: data.location,
      audioNotes: data.audio_notes,
      scriptRead: data.script_read,
      boardLook: data.board_look,
      main: data.main,
      aux: data.aux,
      lowerThird: data.lower_third,
      ribbon: data.ribbon,
      controlRoom: data.control_room,
      category: data.category,
      createdAt: data.created_at,
      updatedAt: data.updated_at,
    }
  } catch (error) {
    console.error("Error in updateShowFlowItem:", error)
    throw error
  }
}

// Replace the getTimelineEvents function with this updated version

export async function getTimelineEvents(gameId: string): Promise<TimelineEvent[]> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      console.log("Timeline events table does not exist, checking localStorage for mock data")

      // Try to get mock events from localStorage
      const eventsFromStorage = JSON.parse(localStorage.getItem("timelineEvents") || "[]")

      // Filter events by gameId if it exists in the mock data
      const gameEvents = eventsFromStorage.filter((e: any) => e.gameId === gameId)

      if (gameEvents.length > 0) {
        console.log("Found timeline events in localStorage:", gameEvents)
        return gameEvents
      }

      // If not found in localStorage, return default mock data
      console.log("Creating mock timeline events for game:", gameId)
      const mockTimelineEvents: TimelineEvent[] = [
        {
          id: "event-1",
          startTime: -1200, // 20 minutes before game start
          endTime: -600, // 10 minutes before game start
          title: "Pregame Show",
          components: ["Graphics Package A", "Music Track 1"],
          notes: "Run the standard pregame hype video.",
          category: "PREGAME",
          location: "Stadium",
        },
        {
          id: "event-2",
          startTime: 0, // Game start
          endTime: 1800, // 30 minutes into the game
          title: "First Quarter",
          components: ["Lower Third A", "Camera Angle 1"],
          notes: "Focus on key players and game highlights.",
          category: "IN GAME",
          location: "Field",
        },
        {
          id: "event-3",
          startTime: 1800, // 30 minutes into the game
          endTime: 2700, // 45 minutes into the game
          title: "Commercial Break",
          components: ["Sponsor Ad 1", "Sponsor Ad 2"],
          notes: "Run sponsor ads during the break.",
          category: "HALFTIME",
          location: "Broadcast",
        },
      ]

      return mockTimelineEvents
    }

    // Check if the timeline_events table exists
    const { error: checkError } = await supabase!.from("timeline_events").select("id").limit(1)

    if (checkError && checkError.message.includes("does not exist")) {
      console.log("Timeline events table does not exist, checking localStorage for mock data")

      // Try to get mock events from localStorage
      const eventsFromStorage = JSON.parse(localStorage.getItem("timelineEvents") || "[]")

      // Filter events by gameId if it exists in the mock data
      const gameEvents = eventsFromStorage.filter((e: any) => e.gameId === gameId)

      if (gameEvents.length > 0) {
        console.log("Found timeline events in localStorage:", gameEvents)
        return gameEvents
      }

      // If not found in localStorage, return default mock data
      console.log("Creating mock timeline events for game:", gameId)
      const mockTimelineEvents: TimelineEvent[] = [
        {
          id: "event-1",
          startTime: -1200, // 20 minutes before game start
          endTime: -600, // 10 minutes before game start
          title: "Pregame Show",
          components: ["Graphics Package A", "Music Track 1"],
          notes: "Run the standard pregame hype video.",
          category: "PREGAME",
          location: "Stadium",
        },
        {
          id: "event-2",
          startTime: 0, // Game start
          endTime: 1800, // 30 minutes into the game
          title: "First Quarter",
          components: ["Lower Third A", "Camera Angle 1"],
          notes: "Focus on key players and game highlights.",
          category: "IN GAME",
          location: "Field",
        },
        {
          id: "event-3",
          startTime: 1800, // 30 minutes into the game
          endTime: 2700, // 45 minutes into the game
          title: "Commercial Break",
          components: ["Sponsor Ad 1", "Sponsor Ad 2"],
          notes: "Run sponsor ads during the break.",
          category: "HALFTIME",
          location: "Broadcast",
        },
      ]

      return mockTimelineEvents
    }

    // If the table exists, fetch the data normally
    const { data, error } = await supabase!
      .from("timeline_events")
      .select("*")
      .eq("game_id", gameId)
      .order("start_time", { ascending: true })

    if (error) {
      console.error("Error fetching timeline events:", error)

      // Try localStorage as fallback
      const eventsFromStorage = JSON.parse(localStorage.getItem("timelineEvents") || "[]")
      const gameEvents = eventsFromStorage.filter((e: any) => e.gameId === gameId)

      if (gameEvents.length > 0) {
        console.log("Found timeline events in localStorage after DB error:", gameEvents)
        return gameEvents
      }

      // Return default mock data
      return [
        {
          id: "event-1",
          startTime: -1200,
          endTime: -600,
          title: "Pregame Show",
          components: ["Graphics Package A", "Music Track 1"],
          notes: "Run the standard pregame hype video.",
          category: "PREGAME",
          location: "Stadium",
        },
        {
          id: "event-2",
          startTime: 0,
          endTime: 1800,
          title: "First Quarter",
          components: ["Lower Third A", "Camera Angle 1"],
          notes: "Focus on key players and game highlights.",
          category: "IN GAME",
          location: "Field",
        },
        {
          id: "event-3",
          startTime: 1800,
          endTime: 2700,
          title: "Commercial Break",
          components: ["Sponsor Ad 1", "Sponsor Ad 2"],
          notes: "Run sponsor ads during the break.",
          category: "HALFTIME",
          location: "Broadcast",
        },
      ]
    }

    return (data || []).map((event) => ({
      id: event.id,
      startTime: event.start_time,
      endTime: event.end_time,
      title: event.title,
      components: event.components || [],
      notes: event.notes || "",
      category: event.category,
      location: event.location || "",
      gameId: event.game_id,
    }))
  } catch (error) {
    console.error("Error in getTimelineEvents:", error)

    // Return default mock data as fallback
    return [
      {
        id: "event-1",
        startTime: -1200,
        endTime: -600,
        title: "Pregame Show",
        components: ["Graphics Package A", "Music Track 1"],
        notes: "Run the standard pregame hype video.",
        category: "PREGAME",
        location: "Stadium",
      },
      {
        id: "event-2",
        startTime: 0,
        endTime: 1800,
        title: "First Quarter",
        components: ["Lower Third A", "Camera Angle 1"],
        notes: "Focus on key players and game highlights.",
        category: "IN GAME",
        location: "Field",
      },
      {
        id: "event-3",
        startTime: 1800,
        endTime: 2700,
        title: "Commercial Break",
        components: ["Sponsor Ad 1", "Sponsor Ad 2"],
        notes: "Run sponsor ads during the break.",
        category: "HALFTIME",
        location: "Broadcast",
      },
    ]
  }
}

// Add this function at the end of the file, just before the last closing brace

export async function testSupabaseConnection(): Promise<boolean> {
  try {
    console.log("Testing Supabase connection...")

    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Cannot test connection.")
      return false
    }

    console.log("Supabase URL:", supabaseUrl)
    console.log("Supabase Key:", supabaseKey ? "Key exists" : "Key missing")

    // Try to query the seasons table - using correct syntax
    const { data, error } = await supabase!.from("seasons").select("*", { count: "exact" })

    if (error) {
      console.error("Error connecting to Supabase:", error)
      return false
    }

    console.log("Successfully connected to Supabase!", data)
    return true
  } catch (error) {
    console.error("Exception when connecting to Supabase:", error)
    return false
  }
}

// Add this function to the lib/db.ts file

export async function createTimelineEvent(event: Omit<TimelineEvent, "id">): Promise<TimelineEvent> {
  try {
    // If Supabase is not available, use mock data immediately
    if (!isSupabaseAvailable()) {
      console.warn("Supabase client not initialized. Using mock data instead.")
      // Check if the timeline_events table exists
      console.warn("Timeline events table does not exist. Using mock data instead.")

      // Generate a unique ID for the event
      const eventId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)

      // Create a complete event object
      const newEvent: TimelineEvent = {
        id: eventId,
        startTime: event.startTime,
        endTime: event.endTime,
        title: event.title,
        components: event.components || [],
        notes: event.notes || "",
        category: event.category,
        location: event.location || "",
      }

      // Store in localStorage
      const existingEvents = JSON.parse(localStorage.getItem("timelineEvents") || "[]")
      existingEvents.push(newEvent)
      localStorage.setItem("timelineEvents", JSON.stringify(existingEvents))

      console.log("Saved timeline event to localStorage:", newEvent)
      return newEvent
    }

    // Check if the timeline_events table exists
    const { error: checkError } = await supabase!.from("timeline_events").select("id").limit(1)

    // If the table doesn't exist, save to localStorage
    if (checkError && checkError.message && checkError.message.includes("does not exist")) {
      console.warn("Timeline events table does not exist. Using mock data instead.")

      // Generate a unique ID for the event
      const eventId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)

      // Create a complete event object
      const newEvent: TimelineEvent = {
        id: eventId,
        startTime: event.startTime,
        endTime: event.endTime,
        title: event.title,
        components: event.components || [],
        notes: event.notes || "",
        category: event.category,
        location: event.location || "",
      }

      // Store in localStorage
      const existingEvents = JSON.parse(localStorage.getItem("timelineEvents") || "[]")
      existingEvents.push(newEvent)
      localStorage.setItem("timelineEvents", JSON.stringify(existingEvents))

      console.log("Saved timeline event to localStorage:", newEvent)
      return newEvent
    }

    // Try to insert into Supabase
    const { data, error } = await supabase!
      .from("timeline_events")
      .insert([
        {
          game_id: event.gameId,
          start_time: event.startTime,
          end_time: event.endTime,
          title: event.title,
          components: event.components || [],
          notes: event.notes || "",
          category: event.category,
          location: event.location || "",
        },
      ])
      .select()
      .single()

    if (error) {
      console.error("Error creating timeline event in Supabase:", error)

      // Save to localStorage as fallback
      const eventId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
      const newEvent: TimelineEvent = {
        id: eventId,
        startTime: event.startTime,
        endTime: event.endTime,
        title: event.title,
        components: event.components || [],
        notes: event.notes || "",
        category: event.category,
        location: event.location || "",
      }

      const existingEvents = JSON.parse(localStorage.getItem("timelineEvents") || "[]")
      existingEvents.push(newEvent)
      localStorage.setItem("timelineEvents", JSON.stringify(existingEvents))

      console.log("Saved timeline event to localStorage after Supabase error:", newEvent)
      return newEvent
    }

    // Convert snake_case to camelCase
    return {
      id: data.id,
      startTime: data.start_time,
      endTime: data.end_time,
      title: data.title,
      components: data.components || [],
      notes: data.notes || "",
      category: data.category,
      location: data.location || "",
    }
  } catch (error) {
    console.error("Error in createTimelineEvent:", error)

    // Save to localStorage as fallback
    const eventId = crypto.randomUUID ? crypto.randomUUID() : Math.random().toString(36).substring(2, 15)
    const newEvent: TimelineEvent = {
      id: eventId,
      startTime: event.startTime,
      endTime: event.endTime,
      title: event.title,
      components: event.components || [],
      notes: event.notes || "",
      category: event.category,
      location: event.location || "",
    }

    const existingEvents = JSON.parse(localStorage.getItem("timelineEvents") || "[]")
    existingEvents.push(newEvent)
    localStorage.setItem("timelineEvents", JSON.stringify(existingEvents))

    console.log("Saved timeline event to localStorage after exception:", newEvent)
    return newEvent
  }
}

