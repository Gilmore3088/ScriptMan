// Core entity types
export interface Season {
  id: string
  title: string
  sport: string
  year: number
  description?: string
  status?: string
  gameCount?: number
  completedGames?: number
  createdAt: string
  updatedAt: string
}

export interface Game {
  id: string
  seasonId: string
  title: string
  date: string
  eventStartTime?: string
  location: string
  theme?: string
  titleSponsor?: string
  broadcastNetwork?: string
  giveaway?: string
  status?: "upcoming" | "completed" | "in-progress"
  eventCount?: number
  completedEvents?: number
  createdAt: string
  updatedAt: string
}

export interface ShowFlowItem {
  id: string
  gameId: string
  itemNumber: number
  startTime: string
  presetTime?: string
  duration?: string
  privateNotes?: string
  clockRef?: string
  location?: string
  audioNotes?: string
  scriptRead: string
  boardLook?: string
  main?: string
  aux?: string
  lowerThird?: string
  ribbon?: string
  controlRoom?: string
  category: string
  createdAt: string
  updatedAt: string
}

export interface Component {
  id: string
  name: string
  type: string
  version: number
  isGlobal: boolean
  description?: string
  content?: string
  createdAt: string
  updatedAt: string
}

export interface Asset {
  id: string
  fileName: string
  fileType: string
  fileSizeBytes: number
  url: string
  uploadedAt: string
}

// Join table interfaces
export interface EventComponent {
  id: string
  showFlowId: string
  componentId: string
}

export interface ShowFlowAsset {
  id: string
  showFlowId: string
  assetId: string
}

export interface ComponentAsset {
  id: string
  componentId: string
  assetId: string
}

// Timeline event interface (derived from ShowFlowItem)
export interface TimelineEvent {
  id: string
  startTime: number // Seconds from game start
  endTime: number // Seconds from game start
  title: string
  components: string[]
  notes?: string
  category: string
  location?: string
}

// Activity interface for tracking user actions
export interface Activity {
  id: string
  action: string
  timestamp: string
  user: string
  entityId?: string
  entityType?: "season" | "game" | "showFlow" | "component" | "asset"
}

