"use client"

import type React from "react"
import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { createShowFlowItem } from "@/lib/db"
import type { ShowFlowItem } from "@/lib/types"
import { toast } from "@/components/ui/use-toast"

interface AddShowFlowItemDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  gameId: string
  onItemAdded: (item: ShowFlowItem) => void
}

export function AddShowFlowItemDialog({ open, onOpenChange, gameId, onItemAdded }: AddShowFlowItemDialogProps) {
  const [activeTab, setActiveTab] = useState("timing")
  const [isSubmitting, setIsSubmitting] = useState(false)

  // Form state
  const [formData, setFormData] = useState({
    // Timing & Identification
    itemNumber: "",
    startTime: "",
    presetTime: "",
    duration: "",
    clockRef: "",

    // Notes & Location
    location: "",
    privateNotes: "",

    // Audio & Visual
    audioNotes: "",
    scriptRead: "",

    // Board / Graphics
    boardLook: "",
    main: "",
    aux: "",
    lowerThird: "",
    ribbon: "",

    // Control Room
    controlRoom: "",

    // Category
    category: "PREGAME",
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const resetForm = () => {
    setFormData({
      itemNumber: "",
      startTime: "",
      presetTime: "",
      duration: "",
      clockRef: "",
      location: "",
      privateNotes: "",
      audioNotes: "",
      scriptRead: "",
      boardLook: "",
      main: "",
      aux: "",
      lowerThird: "",
      ribbon: "",
      controlRoom: "",
      category: "PREGAME",
    })
    setActiveTab("timing")
  }

  const handleSubmit = async (e: React.FormEvent, keepOpen = false) => {
    e.preventDefault()
    console.log("Form submitted with data:", formData)

    // Validate required fields
    if (!formData.scriptRead) {
      console.log("Validation failed: Script Read is required")
      toast({
        title: "Error",
        description: "Script Read is required",
        variant: "destructive",
      })
      return
    }

    try {
      setIsSubmitting(true)
      console.log("Creating new show flow item with data:", formData)

      // Convert itemNumber to a number if provided
      const itemNumber = formData.itemNumber ? Number.parseInt(formData.itemNumber, 10) : 0

      const newItem = {
        gameId,
        itemNumber,
        startTime: formData.startTime,
        presetTime: formData.presetTime,
        duration: formData.duration,
        privateNotes: formData.privateNotes,
        clockRef: formData.clockRef,
        location: formData.location,
        audioNotes: formData.audioNotes,
        scriptRead: formData.scriptRead,
        boardLook: formData.boardLook,
        main: formData.main,
        aux: formData.aux,
        lowerThird: formData.lowerThird,
        ribbon: formData.ribbon,
        controlRoom: formData.controlRoom,
        category: formData.category,
      }

      console.log("Calling createShowFlowItem with:", newItem)
      const createdItem = await createShowFlowItem(newItem)
      console.log("Item created successfully:", createdItem)

      onItemAdded(createdItem)

      toast({
        title: "Success",
        description: "Show flow item added successfully",
      })

      if (!keepOpen) {
        onOpenChange(false)
      }

      resetForm()
    } catch (error) {
      console.error("Error adding show flow item:", error)
      toast({
        title: "Error",
        description: "Failed to add show flow item: " + (error instanceof Error ? error.message : "Unknown error"),
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-auto">
        <DialogHeader>
          <DialogTitle>Add New Show Flow Item</DialogTitle>
        </DialogHeader>

        <form onSubmit={(e) => handleSubmit(e)} className="space-y-4 py-4">
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid grid-cols-5">
              <TabsTrigger value="timing">Timing</TabsTrigger>
              <TabsTrigger value="notes">Notes</TabsTrigger>
              <TabsTrigger value="audio">Audio & Script</TabsTrigger>
              <TabsTrigger value="graphics">Graphics</TabsTrigger>
              <TabsTrigger value="control">Control Room</TabsTrigger>
            </TabsList>

            {/* Timing & Identification */}
            <TabsContent value="timing" className="space-y-4 pt-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="itemNumber">Item Number</Label>
                  <Input
                    id="itemNumber"
                    name="itemNumber"
                    value={formData.itemNumber}
                    onChange={handleChange}
                    placeholder="e.g., 1, A1, Break-1"
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="category">Category</Label>
                  <Select value={formData.category} onValueChange={(value) => handleSelectChange("category", value)}>
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="PREGAME">Pregame</SelectItem>
                      <SelectItem value="IN GAME">In Game</SelectItem>
                      <SelectItem value="HALFTIME">Halftime</SelectItem>
                      <SelectItem value="POSTGAME">Postgame</SelectItem>
                      <SelectItem value="SPONSOR">Sponsor</SelectItem>
                      <SelectItem value="PROMO">Promo</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="startTime">Start Time</Label>
                  <Input
                    id="startTime"
                    name="startTime"
                    value={formData.startTime}
                    onChange={handleChange}
                    placeholder="e.g., 7:40 PM, -10:00"
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="presetTime">Preset Time</Label>
                  <Input
                    id="presetTime"
                    name="presetTime"
                    value={formData.presetTime}
                    onChange={handleChange}
                    placeholder="e.g., -2:00 before start"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="grid gap-2">
                  <Label htmlFor="duration">Duration</Label>
                  <Input
                    id="duration"
                    name="duration"
                    value={formData.duration}
                    onChange={handleChange}
                    placeholder="e.g., 30s, 2m"
                  />
                </div>

                <div className="grid gap-2">
                  <Label htmlFor="clockRef">Clock Reference</Label>
                  <Input
                    id="clockRef"
                    name="clockRef"
                    value={formData.clockRef}
                    onChange={handleChange}
                    placeholder="e.g., 15:00 left in Q2"
                  />
                </div>
              </div>
            </TabsContent>

            {/* Notes & Location */}
            <TabsContent value="notes" className="space-y-4 pt-4">
              <div className="grid gap-2">
                <Label htmlFor="location">Location</Label>
                <Input
                  id="location"
                  name="location"
                  value={formData.location}
                  onChange={handleChange}
                  placeholder="e.g., Stadium, Field, Broadcast Booth"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="privateNotes">Private Notes</Label>
                <Textarea
                  id="privateNotes"
                  name="privateNotes"
                  value={formData.privateNotes}
                  onChange={handleChange}
                  placeholder="Internal notes for staff only"
                  className="min-h-[100px]"
                />
              </div>
            </TabsContent>

            {/* Audio & Script */}
            <TabsContent value="audio" className="space-y-4 pt-4">
              <div className="grid gap-2">
                <Label htmlFor="audioNotes">Audio Notes</Label>
                <Input
                  id="audioNotes"
                  name="audioNotes"
                  value={formData.audioNotes}
                  onChange={handleChange}
                  placeholder="e.g., Play track X, Band, House music"
                />
              </div>

              <div className="grid gap-2">
                <Label htmlFor="scriptRead">
                  Script Read <span className="text-red-500">*</span>
                </Label>
                <Textarea
                  id="scriptRead"
                  name="scriptRead"
                  value={formData.scriptRead}
                  onChange={handleChange}
                  placeholder="The actual script copy to be read or displayed"
                  className="min-h-[150px]"
                  required
                />
              </div>
            </TabsContent>

            {/* Board / Graphics */}
            <TabsContent value="graphics" className="space-y-4 pt-4">
              <div className="grid gap-2">
                <Label htmlFor="boardLook">Board Look</Label>
                <Input
                  id="boardLook"
                  name="boardLook"
                  value={formData.boardLook}
                  onChange={handleChange}
                  placeholder="e.g., Full screen sponsor slide"
                />
              </div>

              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="additional-graphics">
                  <AccordionTrigger>Additional Graphics Options</AccordionTrigger>
                  <AccordionContent>
                    <div className="space-y-4 pt-2">
                      <div className="grid gap-2">
                        <Label htmlFor="main">Main Board</Label>
                        <Input
                          id="main"
                          name="main"
                          value={formData.main}
                          onChange={handleChange}
                          placeholder="Main board content"
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="aux">Aux Board</Label>
                        <Input
                          id="aux"
                          name="aux"
                          value={formData.aux}
                          onChange={handleChange}
                          placeholder="Auxiliary board content"
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="lowerThird">Lower Third</Label>
                        <Input
                          id="lowerThird"
                          name="lowerThird"
                          value={formData.lowerThird}
                          onChange={handleChange}
                          placeholder="e.g., Sponsor name + brief tagline"
                        />
                      </div>

                      <div className="grid gap-2">
                        <Label htmlFor="ribbon">Ribbon</Label>
                        <Input
                          id="ribbon"
                          name="ribbon"
                          value={formData.ribbon}
                          onChange={handleChange}
                          placeholder="e.g., Scrolling sponsor text"
                        />
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </TabsContent>

            {/* Control Room */}
            <TabsContent value="control" className="space-y-4 pt-4">
              <div className="grid gap-2">
                <Label htmlFor="controlRoom">Control Room Notes</Label>
                <Textarea
                  id="controlRoom"
                  name="controlRoom"
                  value={formData.controlRoom}
                  onChange={handleChange}
                  placeholder="e.g., Camera 2 on standby, Trigger pyro at time"
                  className="min-h-[150px]"
                />
              </div>
            </TabsContent>
          </Tabs>

          <DialogFooter className="flex flex-col sm:flex-row gap-2">
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)} disabled={isSubmitting}>
              Cancel
            </Button>
            <div className="flex gap-2">
              <Button type="button" variant="secondary" disabled={isSubmitting} onClick={(e) => handleSubmit(e, true)}>
                {isSubmitting ? "Saving..." : "Save & Add Another"}
              </Button>
              <Button type="submit" disabled={isSubmitting}>
                {isSubmitting ? "Saving..." : "Save Item"}
              </Button>
            </div>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

