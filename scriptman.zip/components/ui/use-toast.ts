"use client"

// Inspired by react-hot-toast library
import { useEffect, useState } from "react"
import type * as React from "react"

import type { ToastActionElement, ToastProps as ToastPropsType } from "@/components/ui/toast"

const TOAST_LIMIT = 5
const TOAST_REMOVE_DELAY = 5000

type ToastProps = {
  id: string
  title?: string
  description?: string
  action?: React.ReactNode
  variant?: "default" | "destructive"
}

const actionTypes = {
  ADD_TOAST: "ADD_TOAST",
  UPDATE_TOAST: "UPDATE_TOAST",
  DISMISS_TOAST: "DISMISS_TOAST",
  REMOVE_TOAST: "REMOVE_TOAST",
} as const

let count = 0

function generateId() {
  return `${count++}`
}

type ToasterToast = ToastPropsType & {
  id: string
  title?: React.ReactNode
  description?: React.ReactNode
  action?: ToastActionElement
}

type ActionType = typeof actionTypes

type Action =
  | {
      type: typeof actionTypes.ADD_TOAST
      toast: ToastProps
    }
  | {
      type: typeof actionTypes.UPDATE_TOAST
      toast: ToastProps
    }
  | {
      type: typeof actionTypes.DISMISS_TOAST
      toastId: string
    }
  | {
      type: typeof actionTypes.REMOVE_TOAST
      toastId: string
    }

interface State {
  toasts: ToastProps[]
}

const toastTimeouts = new Map<string, ReturnType<typeof setTimeout>>()

function dispatch(action: Action) {
  if (action.type === actionTypes.ADD_TOAST) {
    // Set a timeout to dismiss the toast after 5 seconds
    const timeout = setTimeout(() => {
      dispatch({
        type: actionTypes.DISMISS_TOAST,
        toastId: action.toast.id,
      })
    }, TOAST_REMOVE_DELAY)

    toastTimeouts.set(action.toast.id, timeout)

    // Add the toast to the state
    const state = getState()
    setState({
      ...state,
      toasts: [action.toast, ...state.toasts].slice(0, TOAST_LIMIT),
    })
  }

  if (action.type === actionTypes.UPDATE_TOAST) {
    // Update the toast
    const state = getState()
    setState({
      ...state,
      toasts: state.toasts.map((t) => (t.id === action.toast.id ? { ...t, ...action.toast } : t)),
    })
  }

  if (action.type === actionTypes.DISMISS_TOAST) {
    // Clear the timeout
    const timeout = toastTimeouts.get(action.toastId)
    if (timeout) {
      clearTimeout(timeout)
      toastTimeouts.delete(action.toastId)
    }

    // Set a timeout to remove the toast after the animation
    const state = getState()
    setState({
      ...state,
      toasts: state.toasts.map((t) => (t.id === action.toastId ? { ...t, open: false } : t)),
    })

    setTimeout(() => {
      dispatch({
        type: actionTypes.REMOVE_TOAST,
        toastId: action.toastId,
      })
    }, 300)
  }

  if (action.type === actionTypes.REMOVE_TOAST) {
    // Remove the toast from the state
    const state = getState()
    setState({
      ...state,
      toasts: state.toasts.filter((t) => t.id !== action.toastId),
    })
  }
}

// Initial state
const initialState: State = {
  toasts: [],
}

// State management
let state = initialState

function getState() {
  return state
}

function setState(newState: State) {
  state = newState
  listeners.forEach((listener) => listener(state))
}

// Listeners
const listeners = new Set<(state: State) => void>()

export function useToast() {
  const [toasts, setToasts] = useState<ToastProps[]>([])

  useEffect(() => {
    const listener = (state: State) => {
      setToasts(state.toasts)
    }

    listeners.add(listener)
    return () => {
      listeners.delete(listener)
    }
  }, [])

  return {
    toasts,
    toast,
    dismiss: (toastId: string) => {
      dispatch({
        type: actionTypes.DISMISS_TOAST,
        toastId,
      })
    },
  }
}

export function toast({ title, description, action, variant }: Omit<ToastProps, "id">) {
  const id = generateId()

  const update = (props: Omit<ToastProps, "id">) => {
    dispatch({
      type: actionTypes.UPDATE_TOAST,
      toast: { ...props, id },
    })
  }

  const dismiss = () => {
    dispatch({
      type: actionTypes.DISMISS_TOAST,
      toastId: id,
    })
  }

  dispatch({
    type: actionTypes.ADD_TOAST,
    toast: {
      id,
      title,
      description,
      action,
      variant,
    },
  })

  return {
    id,
    dismiss,
    update,
  }
}

