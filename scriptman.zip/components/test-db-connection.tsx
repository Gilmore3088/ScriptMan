"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { toast } from "@/components/ui/use-toast"
import { testSupabaseConnection } from "@/lib/db"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, XCircle, Loader2 } from "lucide-react"

export function TestDbConnection() {
  const [isLoading, setIsLoading] = useState(false)
  const [connectionStatus, setConnectionStatus] = useState<"untested" | "success" | "error">("untested")

  const testConnection = async () => {
    setIsLoading(true)
    try {
      const isConnected = await testSupabaseConnection()

      if (isConnected) {
        setConnectionStatus("success")
        toast({
          title: "Connected to Supabase",
          description: "Database connection successful",
        })
      } else {
        setConnectionStatus("error")
        toast({
          title: "Connection Failed",
          description: "Could not connect to Supabase database. Using localStorage fallbacks instead.",
          variant: "destructive",
        })
      }
    } catch (error) {
      console.error("Exception when testing connection:", error)
      setConnectionStatus("error")
      toast({
        title: "Connection Failed",
        description: error instanceof Error ? error.message : "Unknown error. Using localStorage fallbacks instead.",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Database Connection</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="flex items-center gap-4">
          <Button onClick={testConnection} disabled={isLoading}>
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing...
              </>
            ) : (
              "Test Supabase Connection"
            )}
          </Button>
          {connectionStatus !== "untested" && (
            <div className="flex items-center gap-2">
              {connectionStatus === "success" ? (
                <>
                  <CheckCircle className="h-5 w-5 text-green-500" />
                  <span className="text-green-600">Connected successfully</span>
                </>
              ) : (
                <>
                  <XCircle className="h-5 w-5 text-red-500" />
                  <span className="text-red-600">Connection failed (using localStorage fallback)</span>
                </>
              )}
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

